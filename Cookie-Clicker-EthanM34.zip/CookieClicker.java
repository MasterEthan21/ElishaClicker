import gbs.GBSApp;
import java.awt.Graphics;
import javax.swing.JFrame;
import java.awt.event.ActionEvent;
import java.awt.Image;
import javax.swing.JButton;
public class CookieClicker extends GBSApp
{
  // Declare your private instance variables here...
  private Image elisha1;
  private JButton moreButton;
  private int howMany;
  // Constructor method: initialize instance variables here...
  public CookieClicker(JFrame f)
  {
    super.setBackground(BLUE);
    super.setSize(300, 250);
    //super.setLayout(null);
    f.setTitle("ELISHA CLICKER");
    elisha1 = super.getImage("gbs/elisha.png");
    moreButton = new JButton("CLICKER");
    super.add(moreButton);
    moreButton.addActionListener(this);
    howMany = 1;
  }
  
  // Perform any custom painting (if necessary) in this method
  // Do not modify instance variables here...
  @Override
  public void paintComponent(Graphics g)
  {
    super.paintComponent(g);  //keep this as the first line of this method
    g.setColor(BLACK);
    g.drawImage(elisha1,120,80,this);
    if ( howMany == 1 )
    {
      g.drawString(howMany+" Elisha!", 10, 40);

    }
    else
    {
      g.drawString(howMany+" Elishas!", 10, 40);

    }
  }
  
  // Process GUI input in this method
  @Override
  public void actionPerformed(ActionEvent ae)
  {
    howMany += 1;

    super.repaint();  //keep this as the last line of this method
  }

}