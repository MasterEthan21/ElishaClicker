import gbs.GBSApp;
import javax.swing.JFrame;

public class MainWindow extends Object
{
    
  public static void main(String[] args)
  {
    JFrame.setDefaultLookAndFeelDecorated(false);
    java.awt.EventQueue.invokeLater( 
    new Runnable() 
    { 
      public void run() 
      {
        JFrame fr = new JFrame("Cookie Clicker 2000");
        fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fr.setLocation(10, 10);
        fr.setResizable(false);
        fr.setIconImage(GBSApp.ICON);
        fr.setContentPane(new CookieClicker(fr));
        fr.pack();
        fr.setVisible(true);
      }
    } 
    );
  }
}